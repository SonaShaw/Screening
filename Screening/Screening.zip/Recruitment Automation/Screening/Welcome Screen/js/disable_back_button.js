//window.history.forward();

	function noBack() {
	window.history.forward(); 
	}