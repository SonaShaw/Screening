<?php
echo "others welcome";
?>