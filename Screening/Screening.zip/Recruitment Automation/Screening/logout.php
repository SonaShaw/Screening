
<?php

	include("class/user.php");
	$submit = new user;
	$submit->clear_session();
	$submit->url("index.php");

					
?>