 // hide displayed row
function hideDisplayedRow(s1){
	var s1 = document.getElementById(s1);
	s1.style.visibility = 'hidden';
	s1.style.display = 'none';
}

// show hidden row

function showHiddenRow(s1){
	var s1 = document.getElementById(s1);
	s1.style.visibility = 'visible';
	s1.style.display = 'table-row';
}
